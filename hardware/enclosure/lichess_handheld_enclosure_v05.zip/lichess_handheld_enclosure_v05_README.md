# Lichess Handheld Enclosure v0.5

## Main fix

The front/back case no longer relies on ~35 mm screws.

Each of the six shell fasteners now uses a **deep rear screwdriver well**. The screw head sits only 3.0 mm behind the front/back seam, so a normal **M2.5 x 8 mm** screw can pass through the rear-shell bridge and thread about 5 mm into the front-shell printed pilot boss.

This means:

- front/back shell: 6 × M2.5 x 8 mm
- battery door: 4 × short M2.5 screws (typically 6–8 mm)
- ESP retaining clips: 4 × short M2.5 screws (typically 6 mm)
- display: 4 × short M3 screws (typically 4–6 mm; verify against the actual module stack)

The battery-door, ESP and display screws intentionally do **not** join the two case halves. They only retain their own component. Only the six shell screws join front and back.

## Screw-well geometry

- rear well outer diameter: 9.6 mm
- screwdriver/head access diameter: 6.2 mm
- seam bridge thickness: 3.0 mm
- M2.5 rear through clearance: 2.8 mm
- M2.5 front pilot: 2.10 mm
- recommended shell screw: M2.5 x 8 mm

The screwdriver reaches down the well from the rear face. No ultra-long screw is required.

## Bambu Lab A1 mini

The 2.10 mm pilot is intended for a standard 0.4 mm nozzle FDM print and lets the M2.5 screw form its own thread in the plastic. The fit-test still includes 2.00 / 2.10 / 2.20 mm pilot samples, plus a complete deep-well sample.

## Validation

All exported v0.5 STLs are watertight. The OpenSCAD model retains collision assertions for case/ESP and screen/ESP mounting structures.
